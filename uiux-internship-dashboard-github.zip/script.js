const sidebar = document.getElementById("sidebar");
const menuBtn = document.getElementById("menuBtn");
const themeBtn = document.getElementById("themeBtn");
const toast = document.getElementById("toast");

menuBtn?.addEventListener("click", () => sidebar.classList.toggle("open"));

document.querySelectorAll(".nav-item").forEach(link => {
  link.addEventListener("click", () => sidebar.classList.remove("open"));
});

themeBtn?.addEventListener("click", () => {
  document.body.classList.toggle("light");
  themeBtn.textContent = document.body.classList.contains("light") ? "☾" : "☼";
  showToast("Theme updated ✓");
});

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
}

const tabs = document.querySelectorAll(".proto-tab");
const title = document.getElementById("protoTitle");
const content = document.getElementById("protoContent");

const protoViews = {
  home: {
    title: "Your progress",
    html: `<div class="proto-kpis"><div><small>Completion</small><b>92%</b></div><div><small>XP earned</small><b>350</b></div><div><small>Tasks</small><b>7/7</b></div></div><div class="fake-chart"><span style="height:35%"></span><span style="height:55%"></span><span style="height:42%"></span><span style="height:70%"></span><span style="height:62%"></span><span style="height:86%"></span><span style="height:78%"></span></div>`
  },
  analytics: {
    title: "Design analytics",
    html: `<div class="proto-kpis"><div><small>Consistency</small><b>92%</b></div><div><small>Components</small><b>12</b></div><div><small>Iterations</small><b>18</b></div></div><div class="fake-chart"><span style="height:48%"></span><span style="height:63%"></span><span style="height:58%"></span><span style="height:76%"></span><span style="height:70%"></span><span style="height:90%"></span><span style="height:95%"></span></div>`
  },
  activity: {
    title: "Recent activity",
    html: `<div class="proto-kpis"><div><small>Last update</small><b>2h</b></div><div><small>Reviews</small><b>8</b></div><div><small>Handoff</small><b>Ready</b></div></div><div class="fake-chart"><span style="height:72%"></span><span style="height:40%"></span><span style="height:78%"></span><span style="height:55%"></span><span style="height:88%"></span><span style="height:65%"></span><span style="height:82%"></span></div>`
  }
};

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const view = protoViews[tab.dataset.tab];
    title.textContent = view.title;
    content.innerHTML = view.html;
    showToast("Prototype interaction updated ✓");
  });
});

document.getElementById("filterBtn")?.addEventListener("click", () => {
  showToast("All 7 completed tasks are displayed ✓");
});

document.getElementById("profileBtn")?.addEventListener("click", () => {
  showToast("Profile menu opened");
});
