# UI/UX Internship Dashboard

A portfolio-ready UI/UX project created from an internship workflow covering:

1. Design System Foundations
2. Typography & Colors
3. Wireframing & Page Hierarchies
4. Reusable Buttons & Input Components
5. High-Fidelity Dashboard Page Design
6. Interactive Prototyping & Transitions
7. Developer Handoff Preparation

## Live demo

After uploading to GitHub, enable **Settings → Pages → Deploy from branch** to publish the project with GitHub Pages.

## Features

- Responsive dashboard for desktop, tablet and mobile
- Dark/light theme toggle
- Responsive mobile navigation
- Task/milestone dashboard
- Reusable UI components and states
- Design-token showcase
- Interactive prototype tabs
- Developer handoff specification cards
- Accessible semantic structure and visible focus-friendly controls
- No framework or build step required

## Tech stack

- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts — Inter

## Project structure

```text
uiux-internship-dashboard/
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to run

Open `index.html` directly in a browser, or use VS Code Live Server.

## GitHub upload

```bash
git init
git add .
git commit -m "Create UI UX internship dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/uiux-internship-dashboard.git
git push -u origin main
```

## Design notes

The visual direction uses a dark navy product-dashboard interface with blue/cyan interaction accents, rounded cards, clear hierarchy and consistent spacing. The project intentionally demonstrates the complete workflow from low-fidelity structure to high-fidelity UI, interactive prototype and developer handoff.

## Suggested portfolio description

> Designed and developed a responsive UI/UX internship dashboard that demonstrates design-system thinking, reusable components, information hierarchy, high-fidelity visual design, interactive prototyping and developer handoff documentation. Built as a lightweight HTML/CSS/JavaScript project suitable for GitHub Pages.
